# Filter+

Per-track filter modes for the **Digitakt mk1 (OS 1.54)** and
**Digitone mk1 / Digitone Keys (OS 1.44)**. Filter+ adds 13 filter types, all
cheaper than the stock Elektron filter types, while using each voice's own
FREQ, RESO and filter envelope.

| device | TYPE | modes |
|---|---|---|
| Digitakt | 8..20 | **BP**, **BP2**, **COMB**, **TRASH**, **LP1**, **HP1**, **LP4-**, **HP4-**, **LP2**, **HP2**, **NOTCH**, **COMB-**, **TRASH-** |
| Digitone | 4..16 | **BP**, **BP2**, **COMB**, **TRASH**, **LP1**, **HP1**, **LP4-**, **HP4-**, **LP2**, **HP2**, **NOTCH**, **COMB-**, **TRASH-** |

Stock TYPE values keep running the stock filter. The FLTR page redraws its
FREQ/RES response curve and TYPE-box icon for the new modes; the icon is a
smooth response curve with its pole order (1, 2 or 4).

- Both machines: COMB/TRASH use HARM/DAMP on the second FLTR page's free
  encoders.
- The low-CPU bank: LP1/HP1 are 1-pole, LP4-/HP4- are four cascaded 1-poles,
  LP2/HP2/NOTCH use the shared SVF core, and COMB-/TRASH- are integer-delay
  combs with no fractional read or damping.
- BP/BP2 are the original state-variable band-pass modes; COMB/TRASH are the
  full-featured feedback combs.

> **Note:** Using multiple COMB / TRASH filters will slow down your machine,
> especially poly tracks on the Digitone. Watch and manage your levels when
> adjusting and/or changing filter types.

## Layout

| path | contents |
|---|---|
| `shared/` | firmware-free DSP: SVF/comb/1-pole/2-pole and tables |
| `filterplus-dt/` | Digitakt mk1 adapter, manifest, UI, DT notes |
| `filterplus-dn/` | Digitone mk1/Keys adapter, manifest, UI, DN notes |
| `docs/` | design notes and reference mapping |
| `tests/`, `tools/` | host/emulator checks and generators |
| `releases/` | prebuilt elemods and release packages |

## Build

Needs the m68k cross toolchain, elekloader 0.5+, both stock OS files, and the
matching cores (`core-4.0-os1.54`, `core-dn1-4.0-os1.44`).

```sh
python tools/build_release.py \
    --elekloader <elekloader checkout> \
    --stock-dt <Digitakt_OS1.54.syx> \
    --stock-dn <Digitone_OS1.44.syx> \
    --toolchain-bin <m68k-elf bin>
```

The script builds the two 1.0 elemods, lints and patch-checks both, stages them
in `releases/elemods/`, writes local test `.syx` files under `out/`, and creates
`releases/FilterPlus-1.0.zip`. Override the cores with `--core-dt` / `--core-dn`
if they live elsewhere.

Install with elekloader: add your stock OS, the matching core and the elemod,
then build the custom `.syx` and flash it with Elektron Transfer.

## Device notes

- [Digitakt mk1 - Filter+](filterplus-dt/README.md)
- [Digitone mk1 / Keys - Filter+ DN](filterplus-dn/README.md)

## Testing

```sh
# Digitakt DSP
python tests/filter_model.py
python tests/comb_equivalence.py
python tests/df_bench.py          # needs digiemu's patched Unicorn

# Digitone: builds and runs the shared Filter+ DSP on the host
python tests/df_bench.py          # needs digiemu's patched Unicorn
```

See the device READMEs and `docs/` for the emulator and hardware checks.

## Credits

- **Digital Alchemy DSP** - the Filter+ modes, DSP and FLTR-page drawing.
- **x2k_77-m1** - the original Digitone port and TYPE icons.

## Licence

GPL-2.0-or-later. No Elektron firmware is included or committed.
